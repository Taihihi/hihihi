import React from "react";

const Home = () => {
  return (
    <div className="container">
      <h1 className="text-center mt-5">Welcome to Admin Site!</h1>
    </div>
  );
};

export default Home;
