// import React, { useState, useEffect } from "react";
import React from "react";
const NotFound = (props) => {
  return (
    <div className="container">
      <h1 className="text-center text-primary mt-5">
        <strong className="text-danger">404 Page not found!</strong>
      </h1>
    </div>
  );
};

export default NotFound;
